<?php
include "./img/index.php";
$echo = base64_decode($acak);
?>

<table width="477" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
	<td align="left" valign="top" class="heading">GIS With GOOGLE MAP </td>
  </tr>
  <tr>
	<td align="left" valign="top" style="padding-top:20px;" class="text_left"><div align="left">
	  <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nullam quis turpis eu libero varius vestibulum. In feugiat. Sed et turpis ac risus aliquet rhoncus. Nam cursus molestie metus. Aliquam ac neque nec leo condimentum lobortis. <br />
	      <br />
	      Donec mollis congue mauris. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Praesent sagittis. In porttitor elit sit amet tellus.Pellentesque dignissim iaculis augue. Aenean magna. <br />
	      <br />
        </p>
	  <p align="center"><br />
          <img src="images/google-map.jpg" width="345" height="146"></p>
	  <p align="center">&nbsp;</p>
	  <p align="center"><img src="images/logo-ri32.jpg" width="189" height="141"></p>
	</div></td>
  </tr>
</table>

<script type="text/javascript">
document.oncontextmenu = new Function("alert('Copyright by Ri32 - WebGIS');return false");
</script>