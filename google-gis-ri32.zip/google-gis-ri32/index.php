<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sistem Informasi Bencana - Ri32</title>
<link href="css.css" rel="stylesheet" type="text/css" />

	<script src="./lib/jquery.min.js"></script>
	<script src="./lib/highcharts.js"></script>
	<script src="./lib/modules/exporting.js"></script>
	
	<link rel="stylesheet" href="style.css" />
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
		
	<?php include "koneksi.php";?>
	
</head>

<body>
<table width="780" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <td align="left" valign="top"><table width="780" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td align="left" valign="top" style="background-image:url(images/index_02.gif); background-repeat:repeat-x; padding-top:4px;"><table width="780" border="0" cellspacing="0" cellpadding="0">
          <tr>
            
			<td width="130" align="center" valign="middle">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td align="center" valign="top" class="menu"><a href="?page=home">Home</a></td>
              </tr>
              <tr>
                <td align="center" valign="top"><img src="images/index_05-09.gif" width="34" height="44" alt="" /></td>
              </tr>
            </table>
			</td>

            <td width="2" align="center" valign="top"><img src="images/index_05.gif" alt="" width="2" height="46" /></td>
            <td width="130" align="center" valign="middle"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td align="center" valign="top" class="menu"><a href="?page=data-bencana">Data Bencana</a></td>
              </tr>
              <tr>
                <td align="center" valign="top"><img src="images/index_09-14.gif" width="36" height="44" alt="" /></td>
              </tr>
            </table>
			</td>

			<td width="2" align="center" valign="top"><img src="images/index_05.gif" alt="" width="2" height="46" /></td>
            <td width="130" align="center" valign="middle"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td align="center" valign="top" class="menu"><a href="?page=data-provinsi">Data Provinsi</a></td>
              </tr>
              <tr>
                <td align="center" valign="top"><img src="images/index_09-14.gif" width="36" height="44" alt="" /></td>
              </tr>
            </table>
			</td>

						
            <td width="2" align="center" valign="top"><img src="images/index_05.gif" alt="" width="2" height="46" /></td>
            <td width="130" align="center" valign="middle">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td align="center" valign="top" class="menu"><a href="?page=info-bencana">Info Bencana</a></td>
              </tr>
              <tr>
                <td align="center" valign="top"><img src="images/index_11.gif" width="36" height="44" alt="" /></td>
              </tr>
            </table>
			</td>
			
            
			<td width="2" align="center" valign="top"><img src="images/index_05.gif" alt="" width="2" height="46" /></td>
            <td width="130" align="center" valign="middle">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td align="center" valign="top" class="menu"><a href="?page=statistik">Statistik</a></td>
              </tr>
              <tr>
                <td align="center" valign="top"><img src="images/index_13.gif" width="36" height="44" alt="" /></td>
              </tr>
            </table>
			</td>
			
			
			<td width="2" align="center" valign="top"><img src="images/index_05.gif" alt="" width="2" height="46" /></td>
            <td width="130" align="center" valign="middle">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td align="center" valign="top" class="menu"><a href="?page=peta">Peta</a></td>
              </tr>
              <tr>
                <td align="center" valign="top"><img src="images/index_13.gif" width="36" height="44" alt="" /></td>
              </tr>
            </table>
			</td>

			            
          </tr>
        </table></td>
      </tr>
      <tr>
        <td align="left" valign="top">
            <div style="float:left; width:780px;">
              <div style="float:left; width:489px;"><img src="images/index_28.gif" alt="" width="489" height="172" border="0" usemap="#Map" /></div>
              <div style="float:left; width:291px;"><img src="images/index_29.gif" width="291" height="172" alt="" /></div>
            </div>
          </td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="left" valign="top" style="padding-top:36px;"><table width="780" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="526" height="160" align="left" valign="top">
		
		<!--content web-->
		<?php
		$pg = htmlentities($_GET['page']);	
		$file ="$pg.php";
		if (!file_exists($file)) {
			include ("home.php");
		}else if($pg=="" || $pg=="home"){
			include ("home.php");
		}else{
			include ("$pg.php");
		}
		?>
		
		</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="left" valign="top" style="padding-top:15px;"><table width="780" border="0" cellspacing="0" cellpadding="0" style="background-image:url(images/index_66.gif); background-repeat:repeat-x;">
      <tr>
        <td align="center" valign="middle"><pre class="footer"><a href="index.html">Home</a>     |    <a href="content.html"> About us</a>     |     <a href="content.html">Service</a>     |     <a href="content.html">Faq</a>     |     <a href="content.html">Company</a>     |     <a href="contact.html">Contact us</a> </pre></td>
      </tr>
      <tr>
        <td align="center" valign="middle" class="copyright">right © 2003-2007 Company name.com. All rights reserved </td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
</html>

<iframe width=174 height=189 name="gToday:normal:agenda.js" id="gToday:normal:agenda.js" src="ipopeng.htm" scrolling="no" frameborder="0" style="visibility:visible; z-index:999; position:absolute; top:-500px; left:-500px;">

