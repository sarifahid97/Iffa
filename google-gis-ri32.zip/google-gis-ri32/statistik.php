<script type="text/javascript">
	$(function () {
		var chart;
		$(document).ready(function() {
			chart = new Highcharts.Chart({
				chart: {
					renderTo: 'container',
					plotBackgroundColor: null,
					plotBorderWidth: null,
					plotShadow: false
				},
				title: {
					text: 'Diagram Info Bencana'
				},
				tooltip: {
					formatter: function() {
						return '<b>'+
				this.point.name +'</b>: '+ Highcharts.numberFormat(this.percentage, 2) +' % ('+ this.y +' Kejadian)';
					}
				},
				plotOptions: {
					pie: {
						allowPointSelect: true,
						cursor: 'pointer',
						dataLabels: {
							enabled: true,
							color: '#000000',
							connectorColor: '#000000',
							formatter: function() {
								return '<b>'+ this.point.name +'</b>: '+ Highcharts.numberFormat(this.percentage, 2) +' %';
							}
						}
					}
				},
				series: [{
				   type: 'pie',
					name: 'Browser share',
					data: [
					
					<?php 
						$query=mysql_query("SELECT distinct(nama_bencana) FROM view_informasi");					
	
						while($row=mysql_fetch_assoc($query)){
							 $nama     = $row['nama_bencana'];
							 
							 $data = mysql_fetch_array(mysql_query("SELECT count(id_info) as jumlah FROM view_informasi where nama_bencana='$nama'"));
							 $jumlah = $data['jumlah'];
							?>['<?php echo $nama?>',   <?php echo $jumlah;?>],<?php
						}
					?>
					
					]
				}]
			});
		});
		
	});
	</script>
	
	<div id="container" style="min-width: 350px; height: 350px; margin: 0 auto"></div>
	
	<br><br>
	<h2 align="center"><font color="#666666">Tabel Info Bencana</font></h2>
	
	<table cellpadding="0" cellspacing="0" border="0" id="table" class="sortable">
		<thead>
			<tr>
				<th><h3>Nomor</h3></th>
				<th><h3>Nama Bencana</h3></th>
				<th><h3>Jumlah Kejadian</h3></th>
			</tr>
		</thead>
		<tbody>
		 <?php
			$query=mysql_query("SELECT distinct(nama_bencana) FROM view_informasi");					
	
			while($row=mysql_fetch_assoc($query)){
				 $nama = $row['nama_bencana'];
	
				 $data = mysql_fetch_array(mysql_query("SELECT count(id_info) as jumlah FROM view_informasi where nama_bencana='$nama'"));
				 $jumlah = $data['jumlah']; 
				 ?>
				<tr>
					<td><?php echo $d=$d+1;?></td>
					<td><?php echo $nama;?></td>
					<td><?php echo $jumlah;?></td>
				</tr>
				<?php
			}
		?>
		</tbody>
	</table>
	
	<script type="text/javascript" src="script.js"></script>
	<script type="text/javascript">
		var sorter = new TINY.table.sorter("sorter");
		sorter.head = "head";
		sorter.asc = "asc";
		sorter.desc = "desc";
		sorter.even = "evenrow";
		sorter.odd = "oddrow";
		sorter.evensel = "evenselected";
		sorter.oddsel = "oddselected";
		sorter.paginate = true;
		sorter.currentid = "currentpage";
		sorter.limitid = "pagelimit";
		sorter.init("table",0);
	</script>
