<?php
include "koneksi.php";

$x = $_GET['x'];
$y = $_GET['y'];
$judul = $_GET['judul'];
$des = $_GET['des'];
$jenis  = $_GET['jenis'];

$id_info  = $_GET['id_info'];
$id_prov  = $_GET['id_prov'];
$id_bencana  = $_GET['id_bencana'];
$korban  = $_GET['korban'];
$penyebab  = $_GET['penyebab'];
$tgl  = $_GET['tgl'];

$masuk = mysql_query("insert into tbl_informasi(id_info,korban,penyebab,id_prov,id_bencana,jenis,lat,lng,tgl)
values('$id_info','$korban','$penyebab','$id_prov','$id_bencana','$jenis',$x,$y,'$tgl')");
if($masuk){
    echo "Berhasil Menyimpan Data";
}else{
    echo "Gagal : ".mysql_error();
}
?>
